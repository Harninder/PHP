<?php
require 'config.php';

$sql = "SELECT * FROM employee_details";
$stmt = $pdo->query($sql);

echo "<h2>Employee List</h2>";
echo "<table border='1'>
<tr>
<th>ID</th>
<th>Name</th>
<th>Email</th>
<th>Phone</th>
<th>Position</th>
<th>Hourly Rate</th>
</tr>";

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . $row['Name'] . "</td>";
    echo "<td>" . $row['Email'] . "</td>";
    echo "<td>" . $row['Phone'] . "</td>";
    echo "<td>" . $row['Position'] . "</td>";
    echo "<td>" . $row['Hourly_rate'] . "</td>";
    echo "</tr>";
}

echo "</table>";
?>
