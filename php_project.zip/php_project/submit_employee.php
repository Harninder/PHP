<?php
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $position = $_POST['position'];
    $hourly_rate = $_POST['hourly_rate'];

    $sql = "INSERT INTO employee_details (name, email, phone, position, hourly_rate) VALUES (?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$name, $email, $phone, $position, $hourly_rate]);

    echo "New employee added successfully!";
}
?>
