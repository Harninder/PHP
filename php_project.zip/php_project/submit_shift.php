<?php
require 'config.php';
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $date = $_POST['date'];
    $time = $_POST['time'];
    $location = $_POST['location'];
    $task = $_POST['task'];
    $email = $_POST['email'];
    $rate = $_POST['rate'];

    // Insert shift details into the database
    $sql = "INSERT INTO shifts (date, time, location, task, email, rate) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$date, $time, $location, $task, $email, $rate]);

    // Send an email to the user
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.example.com';  // Set the SMTP server to send through
        $mail->SMTPAuth = true;
        $mail->Username = 'your-email@example.com';  // SMTP username
        $mail->Password = 'your-email-password';    // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Recipients
        $mail->setFrom('your-email@example.com', 'Your Name');
        $mail->addAddress($email);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'New Shift Added';
        $mail->Body    = "Dear User,<br><br>Your new shift has been added successfully.<br><br>
                          <strong>Date:</strong> $date<br>
                          <strong>Time:</strong> $time<br>
                          <strong>Location:</strong> $location<br>
                          <strong>Task:</strong> $task<br>
                          <strong>Rate:</strong> $rate<br><br>
                          Thank you!";

        $mail->send();
        echo 'New shift added successfully and email has been sent!';
    } catch (Exception $e) {
        echo "New shift added successfully but the email could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
